/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetoaulacarros.classes;

/**
 *
 * @author FATEC ZONA LESTE
 */
interface Sedan {

    void start();

    void stop();

    void accelerate();

}
 
interface RetBack {

    void start();

    void stop();

    void accelerate();

}
 
class ChevroletSedan implements Sedan {

    private String modelName;
 
    ChevroletSedan(String sModelName) {

        this.modelName = sModelName;

    }
 
    public void start() {

        System.out.println("BMW Sedan Car Start...");

    }
 
    public void stop() {

        System.out.println("BMW Sedan Car Stop...");

    }
 
    public void accelerate() {

        System.out.println("BMW Sedan Car Accelerate...");

    }

}
 
class ChevroletRetBack implements RetBack {

    private String modelName;
 
    ChevroletRetBack(String sModelName) {

        this.modelName = sModelName;

    }
 
    public void start() {

        System.out.println("BMW HatchBack Car Start...");

    }
 
    public void stop() {

        System.out.println("BMW HatchBack Car Stop...");

    }
 
    public void accelerate() {

        System.out.println("BMW HatchBack Car Accelerate...");

    }

}
 
class BMWSedanCar implements Sedan {

    private String modelName;
 
    BMWSedanCar(String sModelName) {

        this.modelName = sModelName;

    }
 
    public void start() {

        System.out.println("BMW Sedan Car Start...");

    }
 
    public void stop() {

        System.out.println("BMW Sedan Car Stop...");

    }
 
    public void accelerate() {

        System.out.println("BMW Sedan Car Accelerate...");

    }

}
 
class BMWRetBackCar implements RetBack {

    private String modelName;
 
    BMWRetBackCar(String sModelName) {

        this.modelName = sModelName;

    }
 
    public void start() {

        System.out.println("BMW HatchBack Car Start...");

    }
 
    public void stop() {

        System.out.println("BMW HatchBack Car Stop...");

    }
 
    public void accelerate() {

        System.out.println("BMW HatchBack Car Accelerate...");

    }

}
 
interface CarFactory {

    Sedan createSedan();

    RetBack createRetBack();

}
 
class ChevroletCarFactory implements CarFactory {

    public Sedan createSedan() {

        return new ChevroletSedan("Sedan Chevrolet");

    }
 
    public RetBack createRetBack() {

        return new ChevroletRetBack("RetBack Chevrolet");

    }

}
 
class BMWCarFactory implements CarFactory {

    public Sedan createSedan() {

        return new BMWSedanCar("Sedan BMW");

    }
 
    public RetBack createRetBack() {

        return new BMWRetBackCar("HatchBack BMW");

    }

}
 
public class Main {

    public static void main(String[] args) {

        CarFactory pCarFactory = new BMWCarFactory();

        Sedan pSedanCar = pCarFactory.createSedan();
 
        pSedanCar.start();

        pSedanCar.accelerate();

        pSedanCar.stop();
 
        pCarFactory = new BMWCarFactory();

        RetBack pHatchBackCar = pCarFactory.createRetBack();
 
        pHatchBackCar.start();

        pHatchBackCar.accelerate();

        pHatchBackCar.stop();

    }

}